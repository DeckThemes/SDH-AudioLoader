export class Pack {
  data: any;
  name: string = "";
  description: string = "";
  path: string = "";
  ignore: string[] = [];

  init() {
    this.name = this.data.name;
    this.description = this.data.description;
    this.path = this.data.packPath;
    this.ignore = this.data.ignore;
  }
}
