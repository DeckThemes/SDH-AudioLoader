# Audio Loader Encore: Context-Aware Music Low-Pass Filter

This patch targets `jwvdqx/SDH-AudioLoader-Encore` on its `main` branch at the v1.2.4 source layout.

## What it adds

- A master **Enable Context-Aware Low-Pass Filter** toggle.
- An independent **Steam Foreground Menus / Overlay** toggle.
- An independent **Game Launch / Loading** toggle.
- A **Filter Strength** slider from 0 to 100%.
- Persisted settings in Encore's existing `config.json` through its existing `set_config` backend method.
- A Web Audio low-pass stage applied only to Encore's own menu-music player.

The slider maps logarithmically from a 20 kHz cutoff at 0% to 500 Hz at 100%. Filter transitions are smoothed to avoid abrupt clicks. The filter uses a Q of approximately 0.707.

## Detection behavior

**Steam Foreground Menus / Overlay** follows `blur` and `focus` events on Steam's Game Mode shared window. That is the stable cross-view signal available to a Decky plugin for foreground Steam popups such as Quick Access and the Steam menu. Steam does not expose a stable public event that can reliably distinguish every individual popup or selection dialog from this context, so Encore uses one menu toggle rather than inventing separate nonfunctional controls.

**Game Launch / Loading** listens for Steam's `RegisterForGameActionStart` event and only responds to `LaunchApp`. It stays active until Steam ends that action or reports the game process as running. A 15-minute failsafe clears stale launch state if a Steam client event is missed.

## Scope and safety

- Only `HTMLAudioElement` instances used by Encore's menu music are attached to the filter.
- Steam UI sound effects, notifications, voice chat, and game audio are not routed through this filter.
- Existing music volume and Normalize Volume behavior continue to use the audio element's volume property.
- The graph is created only after a user interaction, to avoid suspending autoplayed menu music on plugin startup.
- If Web Audio is unavailable or another plugin has already claimed the media element's source node, the patch logs the problem and fails safely instead of interrupting playback.

## Apply to a checkout

1. Extract this archive.
2. Run the patch applier from the extracted folder, pointing it at your Encore clone:

   ```bash
   python3 apply_feature.py --repo /path/to/SDH-AudioLoader-Encore
   ```

3. Build the plugin from the repository:

   ```bash
   cd /path/to/SDH-AudioLoader-Encore
   pnpm install --frozen-lockfile
   pnpm build
   ```

The applier makes a timestamped backup of each edited file before writing. It checks every source anchor first and refuses to make changes if the checkout differs from the expected v1.2.4 layout.

## Validation status

The new TypeScript module passed an isolated TypeScript compile against the DOM/Web Audio APIs with Steam API type stubs. The complete Encore package build was not run here because the repository checkout and pnpm dependencies could not be fetched in this environment. The patch has not been committed or pushed to GitHub.
