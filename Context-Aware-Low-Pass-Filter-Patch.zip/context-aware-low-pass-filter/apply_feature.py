#!/usr/bin/env python3
"""Apply the Context-Aware Music Low-Pass Filter patch to an Encore checkout."""
from __future__ import annotations

import argparse
import shutil
from datetime import datetime
from pathlib import Path


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f"Expected exactly one match for {label}, found {count}. No files have been changed.")
    return text.replace(old, new, 1)


def read(root: Path, rel: str) -> str:
    path = root / rel
    if not path.is_file():
        raise RuntimeError(f"Required Encore file is missing: {rel}")
    return path.read_text(encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=Path.cwd(), help="Path to the SDH-AudioLoader-Encore checkout")
    args = parser.parse_args()
    root = args.repo.resolve()
    if not (root / "package.json").exists() or '"name": "sdh-audioloader-encore"' not in (root / "package.json").read_text(encoding="utf-8"):
        raise SystemExit("The selected folder is not an SDH-AudioLoader-Encore repository.")

    # Prepare every edit in memory first. If the upstream files differ, fail before writing.
    edits: dict[str, str] = {}

    state = read(root, "src/state/GlobalState.tsx")
    state = replace_once(
        state,
        "  showNowPlaying: boolean;\n  isInstalling: boolean;",
        "  showNowPlaying: boolean;\n  lowPassEnabled: boolean;\n  lowPassSteamMenus: boolean;\n  lowPassGameLaunching: boolean;\n  lowPassStrength: number;\n  isInstalling: boolean;",
        "GlobalState public interface",
    )
    state = replace_once(
        state,
        "  private showNowPlaying: boolean = false;\n  private browserPackList:",
        "  private showNowPlaying: boolean = false;\n  private lowPassEnabled: boolean = false;\n  private lowPassSteamMenus: boolean = false;\n  private lowPassGameLaunching: boolean = false;\n  private lowPassStrength: number = 50;\n  private browserPackList:",
        "GlobalState private defaults",
    )
    state = replace_once(
        state,
        "      showNowPlaying: this.showNowPlaying,\n      browserPackList:",
        "      showNowPlaying: this.showNowPlaying,\n      lowPassEnabled: this.lowPassEnabled,\n      lowPassSteamMenus: this.lowPassSteamMenus,\n      lowPassGameLaunching: this.lowPassGameLaunching,\n      lowPassStrength: this.lowPassStrength,\n      browserPackList:",
        "GlobalState public snapshot",
    )
    edits["src/state/GlobalState.tsx"] = state

    audio_index = read(root, "src/audioPlayers/index.ts")
    audio_index = replace_once(
        audio_index,
        'export * from "./musicGuard";\n',
        'export * from "./musicGuard";\nexport * from "./lowPass";\n',
        "audioPlayers exports",
    )
    edits["src/audioPlayers/index.ts"] = audio_index

    music = read(root, "src/audioPlayers/changeMenuMusic.ts")
    music = replace_once(
        music,
        'import { applyMusicVolume, cachedMusicGain, loudnessSettings, normalizeMusic } from "./loudness";\n',
        'import { applyMusicVolume, cachedMusicGain, loudnessSettings, normalizeMusic } from "./loudness";\nimport { setMusicLowPassPlayer } from "./lowPass";\n',
        "menu music low-pass import",
    )
    music = replace_once(
        music,
        '      setGlobalState("menuMusic", menuMusic);\n',
        '      setMusicLowPassPlayer(menuMusic);\n      setGlobalState("menuMusic", menuMusic);\n',
        "register menu music player with low-pass processor",
    )
    edits["src/audioPlayers/changeMenuMusic.ts"] = music

    index = read(root, "src/index.tsx")
    index = replace_once(
        index,
        "  startMusicGuard,\n} from \"./audioPlayers\";",
        "  startMusicGuard,\n  configureMusicLowPass,\n  startMusicLowPassContextMonitor,\n  stopMusicLowPassAudio,\n} from \"./audioPlayers\";",
        "low-pass imports",
    )
    index = replace_once(
        index,
        "    showNowPlaying,\n    soundVolume,",
        "    showNowPlaying,\n    lowPassEnabled,\n    lowPassSteamMenus,\n    lowPassGameLaunching,\n    lowPassStrength,\n    soundVolume,",
        "low-pass UI state destructuring",
    )

    low_pass_panel = '''      {legacyEnabled && (
        <PanelSection title="Music Low-Pass Filter">
          <PanelSectionRow>
            <ToggleField
              label="Enable Context-Aware Low-Pass Filter"
              description="Applies a gradual low-pass filter to Encore's menu music only. Steam UI sounds and game audio are not changed."
              checked={lowPassEnabled}
              onChange={(value: boolean) => {
                setGlobalState("lowPassEnabled", value);
                configureMusicLowPass({
                  enabled: value,
                  steamMenus: lowPassSteamMenus,
                  gameLaunching: lowPassGameLaunching,
                  strength: lowPassStrength,
                }, true);
                python.setConfig({ low_pass_enabled: value });
              }}
            />
          </PanelSectionRow>
          <PanelSectionRow>
            <ToggleField
              label="Steam Foreground Menus / Overlay"
              description="Filters music while a Steam foreground popup takes focus, such as Quick Access or the Steam menu. Steam does not expose a stable public event for distinguishing every popup type."
              checked={lowPassSteamMenus}
              onChange={(value: boolean) => {
                setGlobalState("lowPassSteamMenus", value);
                configureMusicLowPass({
                  enabled: lowPassEnabled,
                  steamMenus: value,
                  gameLaunching: lowPassGameLaunching,
                  strength: lowPassStrength,
                }, true);
                python.setConfig({ low_pass_steam_menus: value });
              }}
            />
          </PanelSectionRow>
          <PanelSectionRow>
            <ToggleField
              label="Game Launch / Loading"
              description="Filters music from the moment Steam starts the game-launch action until the game process starts or Steam ends the launch action."
              checked={lowPassGameLaunching}
              onChange={(value: boolean) => {
                setGlobalState("lowPassGameLaunching", value);
                configureMusicLowPass({
                  enabled: lowPassEnabled,
                  steamMenus: lowPassSteamMenus,
                  gameLaunching: value,
                  strength: lowPassStrength,
                }, true);
                python.setConfig({ low_pass_game_launching: value });
              }}
            />
          </PanelSectionRow>
          <PanelSectionRow>
            <SliderField
              bottomSeparator="standard"
              label={`Filter Strength (${lowPassStrength}%)`}
              value={lowPassStrength}
              min={0}
              max={100}
              step={1}
              onChange={(value) => {
                setGlobalState("lowPassStrength", value);
                configureMusicLowPass({
                  enabled: lowPassEnabled,
                  steamMenus: lowPassSteamMenus,
                  gameLaunching: lowPassGameLaunching,
                  strength: value,
                }, true);
                python.setConfig({ low_pass_strength: value });
              }}
              icon={<FaMusic />}
            />
          </PanelSectionRow>
        </PanelSection>
      )}
      <PanelSection title="Settings">'''
    index = replace_once(index, '      <PanelSection title="Settings">', low_pass_panel, "Music Low-Pass Filter settings panel")

    # Load persisted options and make them available to the processor.
    index = replace_once(
        index,
        "      const configNowPlaying = data?.show_now_playing ?? false;",
        "      const configNowPlaying = data?.show_now_playing ?? false;\n      const configLowPassEnabled = data?.low_pass_enabled ?? false;\n      const configLowPassSteamMenus = data?.low_pass_steam_menus ?? false;\n      const configLowPassGameLaunching = data?.low_pass_game_launching ?? false;\n      const configLowPassStrength = data?.low_pass_strength ?? 50;",
        "load persisted low-pass settings",
    )
    index = replace_once(
        index,
        '      setGlobalState("showNowPlaying", configNowPlaying);\n      nowPlayingSettings.enabled = configNowPlaying;',
        '      setGlobalState("showNowPlaying", configNowPlaying);\n      setGlobalState("lowPassEnabled", configLowPassEnabled);\n      setGlobalState("lowPassSteamMenus", configLowPassSteamMenus);\n      setGlobalState("lowPassGameLaunching", configLowPassGameLaunching);\n      setGlobalState("lowPassStrength", configLowPassStrength);\n      configureMusicLowPass({\n        enabled: configLowPassEnabled,\n        steamMenus: configLowPassSteamMenus,\n        gameLaunching: configLowPassGameLaunching,\n        strength: configLowPassStrength,\n      });\n      nowPlayingSettings.enabled = configNowPlaying;',
        "initialize low-pass settings after config load",
    )
    index = replace_once(
        index,
        "  const stopMusicGuard = startMusicGuard(state);",
        "  const stopMusicGuard = startMusicGuard(state);\n  const stopLowPassContextMonitor = startMusicLowPassContextMonitor();",
        "start low-pass context monitor",
    )
    index = replace_once(
        index,
        "      stopMusicGuard();\n",
        "      stopMusicGuard();\n      stopLowPassContextMonitor();\n      stopMusicLowPassAudio();\n",
        "stop low-pass monitor and audio graph on dismount",
    )
    edits["src/index.tsx"] = index

    steam_types = read(root, "src/SteamClient.d.ts")
    steam_types = replace_once(
        steam_types,
        "    RegisterForGameActionStart(\n      callback: (\n        actionType: number,\n        strAppId: string,\n        actionName: string\n      ) => any\n    ): RegisteredEvent;",
        "    RegisterForGameActionStart(\n      callback: (\n        gameActionId: number,\n        appId: string,\n        action: string,\n        launchSource?: any\n      ) => any\n    ): RegisteredEvent;\n    RegisterForGameActionEnd(callback: (gameActionId: number) => any): RegisteredEvent;",
        "Steam game-action API declarations",
    )
    edits["src/SteamClient.d.ts"] = steam_types

    main_py = read(root, "main.py")
    main_py = replace_once(
        main_py,
        '  "show_now_playing": False,\n  "loudness_cache": {},',
        '  "show_now_playing": False,\n  "low_pass_enabled": False,\n  "low_pass_steam_menus": False,\n  "low_pass_game_launching": False,\n  "low_pass_strength": 50,\n  "loudness_cache": {},',
        "starter config defaults",
    )
    main_py = replace_once(
        main_py,
        '            "show_now_playing": False,\n            "loudness_cache": {},',
        '            "show_now_playing": False,\n            "low_pass_enabled": False,\n            "low_pass_steam_menus": False,\n            "low_pass_game_launching": False,\n            "low_pass_strength": 50,\n            "loudness_cache": {},',
        "runtime config defaults",
    )
    edits["main.py"] = main_py

    music_guard = read(root, "src/audioPlayers/musicGuard.ts")
    music_guard = replace_once(music_guard, 'export const BUILD_TAG = "v1.2.4";', 'export const BUILD_TAG = "v1.2.5";', "build tag")
    edits["src/audioPlayers/musicGuard.ts"] = music_guard

    package = read(root, "package.json")
    package = replace_once(package, '"version": "1.2.4"', '"version": "1.2.5"', "package version")
    edits["package.json"] = package

    readme = read(root, "README.md")
    readme = replace_once(
        readme,
        '- **Normalize Volume**: makes every sound pack and music pack about equally loud, so the two volume sliders mean the same thing for all packs. Each pack is measured the first time it is used (a few seconds; the result is saved). Quiet packs are boosted and loud ones turned down, by at most about 12 dB. Steam\'s own default sounds are not changed.\n',
        '- **Normalize Volume**: makes every sound pack and music pack about equally loud, so the two volume sliders mean the same thing for all packs. Each pack is measured the first time it is used (a few seconds; the result is saved). Quiet packs are boosted and loud ones turned down, by at most about 12 dB. Steam\'s own default sounds are not changed.\n- **Context-aware Music Low-Pass Filter**: applies a smooth low-pass filter to Encore-managed menu music during Steam foreground popups (such as Quick Access / the Steam menu) and/or while a game is launching. The menu and launch contexts have separate toggles, and a 0-100% strength slider maps from near-transparent filtering (20 kHz) down to a strong 500 Hz cutoff. Steam UI sound effects and game audio are not processed.\n',
        "README legacy features list",
    )
    readme = replace_once(
        readme,
        "The toggles can be used together. With \"New Music Every Day\" and \"New Music Every Replay\" both on, the first music of a new day is the daily pick, and later replays rotate to other packs.\n",
        "The toggles can be used together. With \"New Music Every Day\" and \"New Music Every Replay\" both on, the first music of a new day is the daily pick, and later replays rotate to other packs.\n\nThe low-pass filter uses the Steam Game Mode window's focus changes as the reliable available signal for foreground menu popups. Steam does not currently expose a stable public event that distinguishes every individual popup or selection dialog. The launch context uses Steam's game-action start/end notifications and is cleared when the game process starts.\n",
        "README low-pass implementation note",
    )
    edits["README.md"] = readme

    module_source = (Path(__file__).parent / "src/audioPlayers/lowPass.ts").read_text(encoding="utf-8")
    new_module_path = root / "src/audioPlayers/lowPass.ts"
    if new_module_path.exists():
        raise RuntimeError("src/audioPlayers/lowPass.ts already exists. Refusing to overwrite it.")

    # All checks passed. Create a timestamped backup and then write the edits.
    backup_root = root / f".lowpass-feature-backup-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
    backup_root.mkdir()
    for rel in edits:
        destination = backup_root / rel
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(root / rel, destination)
    for rel, content in edits.items():
        (root / rel).write_text(content, encoding="utf-8")
    new_module_path.write_text(module_source, encoding="utf-8")

    print("Applied Context-Aware Music Low-Pass Filter changes.")
    print(f"Backup: {backup_root}")
    print("Next: pnpm install --frozen-lockfile && pnpm build")


if __name__ == "__main__":
    main()
