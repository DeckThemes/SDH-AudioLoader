#!/usr/bin/env bash
set -euo pipefail

REPO="${1:-$PWD}"
python3 "$(dirname "$0")/apply_feature.py" --repo "$REPO"
cd "$REPO"
pnpm install --frozen-lockfile
pnpm build
test -s dist/index.js
printf '\nBuild succeeded: %s\n' "$REPO/dist/index.js"
