type RegisteredEvent = { unregister(): void };
type AppState = { bRunning: boolean; unAppID: number; nInstanceID: number };
declare namespace SteamClient {
  const Apps: any;
  const GameSessions: any;
}
